const express = require("express");
const authMiddleware = require("../middleware/authMiddleware");

const {
  createResume,
  getUserResumes,
  getSingleResume,
  updateResume,
  deleteResume,
} = require("../controllers/resumeController");

const router = express.Router();

router.post("/", authMiddleware, createResume);
router.get("/", authMiddleware, getUserResumes);
router.get("/:id", authMiddleware, getSingleResume);
router.put("/:id", authMiddleware, updateResume);
router.delete("/:id", authMiddleware, deleteResume);

module.exports = router;