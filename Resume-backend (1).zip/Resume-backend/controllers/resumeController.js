const pool = require("../config/db");

exports.createResume = async (req, res) => {
  try {
    const userId = req.user.id;

    const {
      fullName,
      email,
      phone,
      education,
      skills,
      experience,
      projects,
      certifications,
      template,
    } = req.body;

    const result = await pool.query(
      `INSERT INTO resumes 
      (user_id, full_name, email, phone, education, skills, experience, projects, certifications, template)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
      RETURNING *`,
      [
        userId,
        fullName,
        email,
        phone,
        education,
        skills,
        experience,
        projects,
        certifications,
        template,
      ]
    );

    res.status(201).json({
      message: "Resume created successfully",
      resume: result.rows[0],
    });
  } catch (err) {
    res.status(500).json({ message: "Create resume failed", error: err.message });
  }
};

exports.getUserResumes = async (req, res) => {
  try {
    const userId = req.user.id;

    const result = await pool.query(
      "SELECT * FROM resumes WHERE user_id = $1 ORDER BY created_at DESC",
      [userId]
    );

    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ message: "Get resumes failed", error: err.message });
  }
};

exports.getSingleResume = async (req, res) => {
  try {
    const userId = req.user.id;
    const resumeId = req.params.id;

    const result = await pool.query(
      "SELECT * FROM resumes WHERE id = $1 AND user_id = $2",
      [resumeId, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Resume not found" });
    }

    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ message: "Get resume failed", error: err.message });
  }
};

exports.updateResume = async (req, res) => {
  try {
    const userId = req.user.id;
    const resumeId = req.params.id;

    const {
      fullName,
      email,
      phone,
      education,
      skills,
      experience,
      projects,
      certifications,
      template,
    } = req.body;

    const result = await pool.query(
      `UPDATE resumes SET
      full_name = $1,
      email = $2,
      phone = $3,
      education = $4,
      skills = $5,
      experience = $6,
      projects = $7,
      certifications = $8,
      template = $9
      WHERE id = $10 AND user_id = $11
      RETURNING *`,
      [
        fullName,
        email,
        phone,
        education,
        skills,
        experience,
        projects,
        certifications,
        template,
        resumeId,
        userId,
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Resume not found" });
    }

    res.json({
      message: "Resume updated successfully",
      resume: result.rows[0],
    });
  } catch (err) {
    res.status(500).json({ message: "Update resume failed", error: err.message });
  }
};

exports.deleteResume = async (req, res) => {
  try {
    const userId = req.user.id;
    const resumeId = req.params.id;

    const result = await pool.query(
      "DELETE FROM resumes WHERE id = $1 AND user_id = $2 RETURNING *",
      [resumeId, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Resume not found" });
    }

    res.json({ message: "Resume deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: "Delete resume failed", error: err.message });
  }
};